
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="style1.css">
    <style>
       
    </style>
</head>

<body>
    <header>
        <div class="container">
            <div class="logo">✪ Admin Panel |</div>
           <nav>
            <a href="dashboard.php">Dashboard</a>
            <div class="dropdown">
                <button class="dropbtn">Users&nbsp;&nbsp;&nbsp;</button>
                <div class="dropdown-content">
                    <a href="user-login.php">Add new user</a>
                    <a href="viewusers.php">View All</a>
                </div>
            </div>

            <div class="dropdown">
                <button class="dropbtn ">Products</button>
                <div class="dropdown-content">
                    <a href="add-new-product.php">Add New Products</a>
                    <a href="view-all.php">View All Products</a>

                </div>
            </div>
            <a href="orders.php">Orders</a>

            <a href="logout.php">Logout</a>
        </nav>
        </div>
    </header>

  
</body>

</html>









 