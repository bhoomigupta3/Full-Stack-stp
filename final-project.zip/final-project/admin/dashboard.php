  <?php
   include("adminpanel.php");
   ?>
   <div style="margin: 60px;">
   <h2 class="text-center"><b>Welcome to the Admin Dashboard</b></h2>
<p class="text-center" style="font-size: 20px;">Use the navigation above to manage users, products, and orders.</p>
   </div>
