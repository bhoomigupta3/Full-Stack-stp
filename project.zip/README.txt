# Florify - Flower E-commerce Project

To run this project:

1. Place the project folder inside your XAMPP/htdocs or WAMP/www directory.
2. Import the database:
   - Open phpMyAdmin
   - Create a new database named 'florifydb'
   - Import 'florifydb.sql' file
3. Start Apache and MySQL
4. Open browser and go to: http://localhost/florify/

Login Credentials (if any):
Admin: admin@example.com / password123
